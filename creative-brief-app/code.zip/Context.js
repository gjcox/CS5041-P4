import { createContext } from "react";

export const Context = createContext("You forgot to use a provider.");
